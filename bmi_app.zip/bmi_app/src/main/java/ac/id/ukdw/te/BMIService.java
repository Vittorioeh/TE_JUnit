package ac.id.ukdw.te;

public class BMIService {

    // Menghitung BMI berdasarkan berat badan dan tinggi badan
    public static double hitungBMI(double beratBadan, double tinggiBadan) {
        if (beratBadan <= 0 || tinggiBadan <= 0) {
            throw new IllegalArgumentException("Berat badan dan tinggi badan harus lebih besar dari 0.");
        }
        if (beratBadan < 20 || tinggiBadan < 1.0) {
            throw new IllegalArgumentException("Berat dan tinggi harus sesuai dengan standar minimal (berat ≥ 20kg dan tinggi ≥ 1.0m).");
        }
        if (beratBadan > 250 || tinggiBadan > 2.8) {
            throw new IllegalArgumentException("Berat dan tinggi harus sesuai dengan standar maksimal (berat ≤ 250kg dan tinggi ≤ 2.8m).");
        }
        return beratBadan / (tinggiBadan * tinggiBadan);
    }

    // Mengklasifikasikan BMI
    public static String klasifikasiBMI(double bmi) {
        if (bmi < 18.5) {
            return "Kurang berat badan";
        } else if (bmi < 24.9) {
            return "Normal";
        } else if (bmi < 29.9) {
            return "Kelebihan berat badan";
        } else {
            return "Obesitas";
        }
    }
}
