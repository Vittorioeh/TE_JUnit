package ac.id.ukdw.te;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 * Test class untuk BMIService
 */
public class BMIServiceTest {

    @ParameterizedTest(name = "Berat: {0} kg, Tinggi: {1} m -> Expected BMI: {2}")
    @CsvSource({
        // Equivalence Partitioning (EP)
        "50, 1.6, 19.53, Normal",
        "45, 1.7, 15.57, Kurang berat badan",
        "95, 1.6, 37.11, Obesitas",

        // Boundary Value Analysis (BVA)
        "70, 1.7, 24.22, Normal",
        "85, 1.7, 29.41, Kelebihan berat badan"
    })
    void shouldCalculateAndClassifyBMICorrectly(double berat, double tinggi, double expectedBMI, String expectedCategory) {
        double bmi = BMIService.hitungBMI(berat, tinggi);
        double roundedBmi = Math.round(bmi * 100.0) / 100.0;
        System.out.println("Berat: " + berat + " kg, Tinggi: " + tinggi + " m, BMI: " + roundedBmi);
        assertEquals(expectedBMI, roundedBmi, 0.01);

        String kategori = BMIService.klasifikasiBMI(bmi);
        System.out.println("BMI: " + roundedBmi + " -> Kategori: " + kategori);
        assertEquals(expectedCategory, kategori);
    }

    @Test
    void shouldThrowExceptionWhenInputIsNegative() {
        assertThrows(IllegalArgumentException.class, () -> BMIService.hitungBMI(-60, 1.7));
        assertThrows(IllegalArgumentException.class, () -> BMIService.hitungBMI(60, -1.7));
    }

    @Test
    void shouldSkipTestWhenInputIsZero() {
        double berat = 0;
        double tinggi = 0;

        Assumptions.assumeTrue(berat > 0 && tinggi > 0, "Input berat dan tinggi harus lebih dari 0, tes dihentikan.");

        double bmi = BMIService.hitungBMI(berat, tinggi);
        String kategori = BMIService.klasifikasiBMI(bmi);
        System.out.println("Berat: " + berat + " kg, Tinggi: " + tinggi + " m, BMI: " + bmi + ", Kategori: " + kategori);
        assertNotNull(kategori);
        fail("Seharusnya tidak sampai ke sini karena input nol");
    }

    @Test
    void shouldThrowExceptionForInputBelowMinimum() {
        assertThrows(IllegalArgumentException.class, () -> {
            System.out.println("Menghitung BMI dengan berat 19 kg dan tinggi 1.5 m (berat di bawah minimal)...");
            BMIService.hitungBMI(19, 1.5);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            System.out.println("Menghitung BMI dengan berat 50 kg dan tinggi 0.9 m (tinggi di bawah minimal)...");
            BMIService.hitungBMI(50, 0.9);
        });
    }

    @Test
    void shouldThrowExceptionForInputAboveMaximum() {
        assertThrows(IllegalArgumentException.class, () -> {
            System.out.println("Menghitung BMI dengan berat 260 kg dan tinggi 1.8 m (berat di atas maksimal)...");
            BMIService.hitungBMI(260, 1.8);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            System.out.println("Menghitung BMI dengan berat 70 kg dan tinggi 2.9 m (tinggi di atas maksimal)...");
            BMIService.hitungBMI(70, 2.9);
        });
    }

    @ParameterizedTest(name = "BMI: {0} -> Expected Category: {1}")
    @CsvSource({
        "15.0, Kurang berat badan",
        "22.5, Normal",
        "27.0, Kelebihan berat badan",
        "32.0, Obesitas"
    })
    void shouldClassifyBMI(double bmi, String expectedCategory) {
        String kategori = BMIService.klasifikasiBMI(bmi);
        System.out.println("BMI: " + bmi + " -> Kategori: " + kategori);
        assertEquals(expectedCategory, kategori);
    }
}